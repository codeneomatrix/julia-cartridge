# This file is a part of Julia. License is MIT: https://julialang.org/license

touch(joinpath(@__DIR__, "buildartifact"))
