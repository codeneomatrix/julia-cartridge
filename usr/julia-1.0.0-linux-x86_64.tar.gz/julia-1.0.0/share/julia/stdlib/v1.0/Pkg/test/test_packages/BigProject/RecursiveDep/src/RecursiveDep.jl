# This file is a part of Julia. License is MIT: https://julialang.org/license

module RecursiveDep

using RecursiveDep2

end