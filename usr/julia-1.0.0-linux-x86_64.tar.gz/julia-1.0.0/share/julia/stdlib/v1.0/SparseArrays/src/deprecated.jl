# This file is a part of Julia. License is MIT: https://julialang.org/license

# BEGIN 1.0 deprecations

# END 1.0 deprecations
