# UUIDs

```@meta
DocTestSetup = :(using UUIDs, Random)
```

```@docs
UUIDs.uuid1
UUIDs.uuid4
UUIDs.uuid_version
```

```@meta
DocTestSetup = nothing
```
