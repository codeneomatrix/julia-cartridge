# Printf

```@meta
DocTestSetup = :(using Printf)
```

```@docs
Printf.@printf
Printf.@sprintf
```

```@meta
DocTestSetup = nothing
```
