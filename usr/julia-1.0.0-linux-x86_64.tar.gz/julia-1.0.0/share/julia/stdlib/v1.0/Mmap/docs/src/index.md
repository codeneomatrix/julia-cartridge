# Memory-mapped I/O

```@meta
DocTestSetup = :(using Mmap)
```

```@docs
Mmap.Anonymous
Mmap.mmap
Mmap.sync!
```

```@meta
DocTestSetup = nothing
```
