# Delimited Files

```@meta
DocTestSetup = :(using DelimitedFiles)
```

```@docs
DelimitedFiles.readdlm(::Any, ::AbstractChar, ::Type, ::AbstractChar)
DelimitedFiles.readdlm(::Any, ::AbstractChar, ::AbstractChar)
DelimitedFiles.readdlm(::Any, ::AbstractChar, ::Type)
DelimitedFiles.readdlm(::Any, ::AbstractChar)
DelimitedFiles.readdlm(::Any, ::Type)
DelimitedFiles.readdlm(::Any)
DelimitedFiles.writedlm
```

```@meta
DocTestSetup = nothing
```
