# Base64

```@meta
DocTestSetup = :(using Base64)
```

```@docs
Base64.Base64EncodePipe
Base64.base64encode
Base64.Base64DecodePipe
Base64.base64decode
Base64.stringmime
```

```@meta
DocTestSetup = nothing
```
